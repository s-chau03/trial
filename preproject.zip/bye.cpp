#include "systemc.h"
#include "bye.h"

void bye_world::say_bye() {    
	//Print "Bye World" to the console.    
	cout << "Bye World.\n";  
} 
